# NeuroCare Frontend

React + TypeScript + Vite + Tailwind CSS frontend for the NeuroCare CDSS
platform. Replaces the original embedded Vue/CDN single-page UI.

## Setup

```bash
npm install
npm run dev
```

The dev server runs on http://localhost:5173 and proxies `/api/*` requests to
the FastAPI backend at http://localhost:8000 (see `vite.config.ts`).

## Build

```bash
npm run build
npm run preview
```

## Structure

```
src/
├── components/   Navbar, Sidebar, Card, AlertBox, AssessmentForm,
│                 RecommendationCard, ChatWindow
├── pages/        Dashboard, Assessment, Assistant, Login, Register
├── services/api.ts   Axios client + typed API calls, JWT interceptor
├── hooks/useAuth.ts  Auth state (token in localStorage)
├── App.tsx        Routing (React Router) + protected routes
└── main.tsx
```

## Notes

* JWT is stored in `localStorage` under `neurocare_token` and attached to
  every API request automatically. A 401 response redirects to `/login`.
* Disease-specific assessment fields are driven by the same
  `diseaseSymptomsMap` used in the legacy Vue implementation, now typed in
  `AssessmentForm.tsx`.
