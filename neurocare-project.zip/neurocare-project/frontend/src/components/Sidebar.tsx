import { NavLink } from "react-router-dom";

const links = [
  { to: "/", label: "Dashboard", exact: true },
  { to: "/assessment", label: "New Assessment" },
  { to: "/assistant", label: "NeuroCare Assistant" },
];

export default function Sidebar() {
  return (
    <aside className="hidden lg:block w-56 shrink-0">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-3 sticky top-4">
        <p className="text-xs font-bold uppercase text-slate-400 px-2 mb-2">
          Navigation
        </p>
        <nav className="flex flex-col gap-1">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.exact}
              className={({ isActive }) =>
                `px-3 py-2 rounded-lg text-sm font-medium ${
                  isActive
                    ? "bg-blue-100 text-blue-900"
                    : "text-slate-600 hover:bg-slate-50"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      </div>
    </aside>
  );
}
