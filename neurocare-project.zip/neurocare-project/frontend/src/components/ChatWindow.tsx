import { useEffect, useRef, useState } from "react";
import { ChatMessage, sendChatMessage } from "../services/api";

interface ChatWindowProps {
  severity: string;
}

export default function ChatWindow({ severity }: ChatWindowProps) {
  const [chatInput, setChatInput] = useState("");
  const [chatLog, setChatLog] = useState<ChatMessage[]>([
    {
      sender: "assistant",
      text: "Welcome. Complete an assessment, then ask me follow-up questions about your recommendations.",
    },
  ]);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight });
  }, [chatLog]);

  const handleSend = async () => {
    const text = chatInput.trim();
    if (!text) return;
    setChatLog((prev) => [...prev, { sender: "user", text }]);
    setChatInput("");

    try {
      const response = await sendChatMessage(text, severity);
      setChatLog((prev) => [...prev, { sender: "assistant", text: response }]);
    } catch {
      setChatLog((prev) => [
        ...prev,
        { sender: "assistant", text: "Communication framework tracking timeout error." },
      ]);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-[350px]">
      <div className="bg-slate-800 text-white p-3 text-sm font-bold flex justify-between items-center">
        <span>NeuroCare Assistant</span>
        <span className="text-[10px] font-normal text-slate-400">Context-Aware Interface</span>
      </div>
      <div ref={boxRef} className="flex-1 p-3 overflow-y-auto space-y-2 text-xs">
        {chatLog.map((msg, idx) => (
          <div
            key={idx}
            className={`p-2 rounded-lg max-w-[85%] ${
              msg.sender === "user" ? "bg-blue-500 text-white ml-auto" : "bg-slate-100 text-slate-800"
            }`}
          >
            {msg.text}
          </div>
        ))}
      </div>
      <div className="p-2 border-t flex gap-1 bg-slate-50">
        <input
          type="text"
          value={chatInput}
          onChange={(e) => setChatInput(e.target.value)}
          onKeyUp={(e) => e.key === "Enter" && handleSend()}
          placeholder="Ask follow-up questions..."
          className="flex-1 p-2 border text-xs rounded bg-white"
        />
        <button
          onClick={handleSend}
          className="bg-slate-800 text-white px-3 text-xs rounded font-bold hover:bg-slate-900"
        >
          Send
        </button>
      </div>
    </div>
  );
}
