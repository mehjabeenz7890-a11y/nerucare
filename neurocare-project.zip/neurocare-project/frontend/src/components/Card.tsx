import { ReactNode } from "react";

interface CardProps {
  title?: string;
  children: ReactNode;
  className?: string;
}

export default function Card({ title, children, className = "" }: CardProps) {
  return (
    <div className={`bg-white p-6 rounded-xl shadow-sm border border-slate-200 ${className}`}>
      {title && (
        <h2 className="text-xl font-bold text-slate-900 mb-4 border-b pb-2">{title}</h2>
      )}
      {children}
    </div>
  );
}
