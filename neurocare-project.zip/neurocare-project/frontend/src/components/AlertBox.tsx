interface AlertBoxProps {
  variant?: "info" | "warning" | "danger" | "success";
  title?: string;
  children: React.ReactNode;
}

const styles: Record<string, string> = {
  info: "bg-blue-50 border-blue-200 text-blue-900",
  warning: "bg-amber-50 border-amber-200 text-amber-900",
  danger: "bg-red-50 border-red-200 text-red-900",
  success: "bg-green-50 border-green-200 text-green-900",
};

export default function AlertBox({ variant = "info", title, children }: AlertBoxProps) {
  return (
    <div className={`border p-4 rounded-lg text-sm space-y-1 ${styles[variant]}`}>
      {title && <p className="font-bold">{title}</p>}
      <div>{children}</div>
    </div>
  );
}
