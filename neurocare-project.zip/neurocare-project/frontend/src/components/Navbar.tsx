import { Link, useNavigate } from "react-router-dom";

interface NavbarProps {
  isAuthenticated: boolean;
  onLogout: () => void;
}

export default function Navbar({ isAuthenticated, onLogout }: NavbarProps) {
  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();
    navigate("/login");
  };

  return (
    <header className="bg-blue-900 text-white p-4 shadow-md">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold tracking-tight flex items-center">
          NeuroCare
          <span className="text-sm font-light uppercase bg-blue-700 px-2 py-1 rounded ml-2">
            CDSS Core
          </span>
        </Link>
        <nav className="flex items-center gap-4 text-sm">
          {isAuthenticated ? (
            <>
              <Link to="/" className="hover:text-blue-200">Dashboard</Link>
              <Link to="/assessment" className="hover:text-blue-200">New Assessment</Link>
              <Link to="/assistant" className="hover:text-blue-200">Assistant</Link>
              <button
                onClick={handleLogout}
                className="bg-blue-700 hover:bg-blue-600 px-3 py-1 rounded font-semibold"
              >
                Log Out
              </button>
            </>
          ) : (
            <Link to="/login" className="bg-blue-700 hover:bg-blue-600 px-3 py-1 rounded font-semibold">
              Sign In
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
