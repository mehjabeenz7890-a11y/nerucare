import { useState } from "react";
import { AssessmentPayload } from "../services/api";

const DISEASES = [
  "Parkinson's Disease",
  "Alzheimer's Disease",
  "Multiple Sclerosis",
  "Huntington's Disease",
];

const DISEASE_SYMPTOMS_MAP: Record<string, string[]> = {
  "Parkinson's Disease": ["Hand Tremor", "Muscle Rigidity", "Walking Difficulty", "Balance Problems"],
  "Alzheimer's Disease": ["Memory Problems", "Difficulty Performing Daily Activities", "Attention Difficulty"],
  "Multiple Sclerosis": ["Muscle Weakness", "Balance Problems", "Walking Difficulty", "Fatigue"],
  "Huntington's Disease": ["Speech Difficulty", "Swallowing Difficulty", "Balance Problems", "Difficulty Performing Daily Activities"],
};

const SYMPTOM_LEVELS = ["None", "Mild", "Moderate", "Severe"];

interface AssessmentFormProps {
  onSubmit: (payload: AssessmentPayload) => void;
  submitting?: boolean;
}

export default function AssessmentForm({ onSubmit, submitting }: AssessmentFormProps) {
  const [disease, setDisease] = useState("");
  const [fallsLastMonth, setFallsLastMonth] = useState(0);
  const [age, setAge] = useState(65);
  const [gender, setGender] = useState("Male");
  const [sleepQuality, setSleepQuality] = useState("Good");
  const [physicalActivity, setPhysicalActivity] = useState("Light");
  const [fatigue, setFatigue] = useState("None");
  const [symptoms, setSymptoms] = useState<Record<string, string>>({});

  const dynamicSymptomList = disease ? DISEASE_SYMPTOMS_MAP[disease] || [] : [];

  const handleDiseaseChange = (value: string) => {
    setDisease(value);
    const initial: Record<string, string> = {};
    (DISEASE_SYMPTOMS_MAP[value] || []).forEach((s) => {
      initial[s] = "None";
    });
    setSymptoms(initial);
  };

  const handleSubmit = () => {
    if (!disease) return;
    onSubmit({
      disease,
      symptoms,
      falls_last_month: fallsLastMonth,
      age,
      gender,
      sleep_quality: sleepQuality,
      physical_activity: physicalActivity,
      fatigue,
    });
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-700">
            Confirmed Disease Profile
          </label>
          <select
            value={disease}
            onChange={(e) => handleDiseaseChange(e.target.value)}
            className="w-full mt-1 p-2 border border-slate-300 rounded-md bg-white"
          >
            <option value="">-- Choose Diagnosis --</option>
            {DISEASES.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700">
            Recent Fall Incidence Count (Past Month)
          </label>
          <input
            type="number"
            min={0}
            max={10}
            value={fallsLastMonth}
            onChange={(e) => setFallsLastMonth(Number(e.target.value))}
            className="w-full mt-1 p-2 border border-slate-300 rounded-md"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-50 p-3 rounded-lg text-xs">
        <div>
          <label className="font-medium text-slate-600">Age</label>
          <input
            type="number"
            value={age}
            onChange={(e) => setAge(Number(e.target.value))}
            className="w-full mt-1 p-1 border rounded"
          />
        </div>
        <div>
          <label className="font-medium text-slate-600">Gender</label>
          <select
            value={gender}
            onChange={(e) => setGender(e.target.value)}
            className="w-full mt-1 p-1 border rounded bg-white"
          >
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
        </div>
        <div>
          <label className="font-medium text-slate-600">Sleep Status</label>
          <select
            value={sleepQuality}
            onChange={(e) => setSleepQuality(e.target.value)}
            className="w-full mt-1 p-1 border rounded bg-white"
          >
            {["Excellent", "Good", "Fair", "Poor"].map((v) => (
              <option key={v} value={v}>{v}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="font-medium text-slate-600">Fatigue</label>
          <select
            value={fatigue}
            onChange={(e) => setFatigue(e.target.value)}
            className="w-full mt-1 p-1 border rounded bg-white"
          >
            {SYMPTOM_LEVELS.map((v) => (
              <option key={v} value={v}>{v}</option>
            ))}
          </select>
        </div>
      </div>

      {disease && (
        <div className="space-y-4 border-t pt-4">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-blue-800">
            Dynamic Clinical Fields: {disease}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {dynamicSymptomList.map((symptom) => (
              <div key={symptom}>
                <label className="block text-sm font-medium text-slate-700">{symptom}</label>
                <select
                  value={symptoms[symptom] || "None"}
                  onChange={(e) =>
                    setSymptoms((prev) => ({ ...prev, [symptom]: e.target.value }))
                  }
                  className="w-full mt-1 p-2 border border-slate-300 rounded-md bg-white"
                >
                  {SYMPTOM_LEVELS.map((v) => (
                    <option key={v} value={v}>{v}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>

          <button
            onClick={handleSubmit}
            disabled={submitting}
            className="w-full bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg shadow hover:bg-blue-800 transition mt-4 disabled:opacity-60"
          >
            {submitting ? "Analyzing..." : "Analyze & Generate Clinical Recommendations"}
          </button>
        </div>
      )}
    </div>
  );
}
