import { TherapyRecommendation } from "../services/api";

export default function RecommendationCard({ rec }: { rec: TherapyRecommendation }) {
  return (
    <div className="border border-slate-100 p-3 rounded-lg bg-slate-50">
      <h4 className="font-bold text-blue-900 text-base">{rec.therapy}</h4>
      <p className="text-xs text-slate-600 mt-1 mb-2">
        <strong>Reasoning Engine:</strong> {rec.reason}
      </p>
      <div className="flex flex-wrap gap-1">
        {rec.exercises.map((ex) => (
          <span
            key={ex}
            className="bg-blue-100 text-blue-800 text-[10px] font-semibold px-2 py-0.5 rounded"
          >
            {ex}
          </span>
        ))}
      </div>
    </div>
  );
}
