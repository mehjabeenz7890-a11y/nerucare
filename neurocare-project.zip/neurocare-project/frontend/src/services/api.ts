import axios, { AxiosError } from "axios";

const api = axios.create({
  baseURL: "/api",
  headers: { "Content-Type": "application/json" },
});

// Attach JWT bearer token to every request if present
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("neurocare_token");
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Redirect to login on 401s
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      localStorage.removeItem("neurocare_token");
      if (window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

// ---------- Types ----------
export interface TherapyRecommendation {
  therapy: string;
  reason: string;
  exercises: string[];
}

export interface AssessmentResponse {
  id?: number;
  predicted_severity: "Low" | "Moderate" | "High" | string;
  recommendations: TherapyRecommendation[];
  high_risk_warning?: string | null;
  created_at?: string;
}

export interface AssessmentHistoryItem extends AssessmentResponse {
  disease: string;
  age: number;
  gender: string;
}

export interface AssessmentPayload {
  disease: string;
  symptoms: Record<string, string>;
  falls_last_month: number;
  age: number;
  gender: string;
  sleep_quality: string;
  physical_activity: string;
  fatigue: string;
}

export interface ChatMessage {
  sender: "user" | "assistant";
  text: string;
}

// ---------- Auth ----------
export async function registerUser(data: {
  username: string;
  email: string;
  password: string;
  full_name?: string;
}) {
  const res = await api.post("/auth/register", data);
  return res.data;
}

export async function loginUser(username: string, password: string) {
  const form = new URLSearchParams();
  form.append("username", username);
  form.append("password", password);
  const res = await api.post("/auth/login", form, {
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  });
  return res.data as { access_token: string; token_type: string };
}

// ---------- Assessment ----------
export async function submitAssessment(
  payload: AssessmentPayload
): Promise<AssessmentResponse> {
  const res = await api.post("/assessment", payload);
  return res.data;
}

export async function getAssessmentHistory(): Promise<AssessmentHistoryItem[]> {
  const res = await api.get("/assessment/history");
  return res.data;
}

// ---------- Chat ----------
export async function sendChatMessage(
  message: string,
  severity: string
): Promise<string> {
  const res = await api.post("/chat", { message, severity });
  return res.data.response;
}

export default api;
