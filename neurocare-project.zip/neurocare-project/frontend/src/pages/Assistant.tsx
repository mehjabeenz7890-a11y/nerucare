import ChatWindow from "../components/ChatWindow";
import Card from "../components/Card";

export default function Assistant() {
  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <Card title="NeuroCare Assistant">
        <p className="text-sm text-slate-600">
          Ask general questions about your recommendation report, disease education,
          or exercise adherence. The assistant cannot modify your physician's
          prescriptions and will defer to a specialist for high-risk cases.
        </p>
      </Card>
      <ChatWindow severity="Unknown" />
    </div>
  );
}
