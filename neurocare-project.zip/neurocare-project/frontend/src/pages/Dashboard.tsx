import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Card from "../components/Card";
import AlertBox from "../components/AlertBox";
import { AssessmentHistoryItem, getAssessmentHistory } from "../services/api";

const SEVERITY_STYLES: Record<string, string> = {
  Low: "bg-green-600",
  Moderate: "bg-orange-500",
  High: "bg-red-600",
};

export default function Dashboard() {
  const [history, setHistory] = useState<AssessmentHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getAssessmentHistory()
      .then(setHistory)
      .catch(() => setError("Unable to load assessment history."))
      .finally(() => setLoading(false));
  }, []);

  const stats = {
    total: history.length,
    high: history.filter((h) => h.predicted_severity === "High").length,
    moderate: history.filter((h) => h.predicted_severity === "Moderate").length,
    low: history.filter((h) => h.predicted_severity === "Low").length,
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <p className="text-xs uppercase font-bold text-slate-400">Total Assessments</p>
          <p className="text-3xl font-bold text-slate-900 mt-1">{stats.total}</p>
        </Card>
        <Card>
          <p className="text-xs uppercase font-bold text-slate-400">Low Severity</p>
          <p className="text-3xl font-bold text-green-600 mt-1">{stats.low}</p>
        </Card>
        <Card>
          <p className="text-xs uppercase font-bold text-slate-400">Moderate Severity</p>
          <p className="text-3xl font-bold text-orange-500 mt-1">{stats.moderate}</p>
        </Card>
        <Card>
          <p className="text-xs uppercase font-bold text-slate-400">High Severity</p>
          <p className="text-3xl font-bold text-red-600 mt-1">{stats.high}</p>
        </Card>
      </div>

      <Card title="Severity History">
        {loading && <p className="text-sm text-slate-400">Loading history...</p>}
        {error && <AlertBox variant="danger">{error}</AlertBox>}
        {!loading && !error && history.length === 0 && (
          <div className="text-center text-slate-400 py-8 text-sm">
            No assessments yet.{" "}
            <Link to="/assessment" className="text-blue-700 font-semibold">
              Start your first assessment
            </Link>
            .
          </div>
        )}
        {!loading && history.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs uppercase text-slate-400 border-b">
                <tr>
                  <th className="py-2 pr-4">Date</th>
                  <th className="py-2 pr-4">Disease</th>
                  <th className="py-2 pr-4">Age</th>
                  <th className="py-2 pr-4">Gender</th>
                  <th className="py-2 pr-4">Severity</th>
                  <th className="py-2 pr-4">Recommendations</th>
                </tr>
              </thead>
              <tbody>
                {history.map((item) => (
                  <tr key={item.id} className="border-b last:border-0">
                    <td className="py-2 pr-4 text-slate-500">
                      {item.created_at ? new Date(item.created_at).toLocaleDateString() : "-"}
                    </td>
                    <td className="py-2 pr-4">{item.disease}</td>
                    <td className="py-2 pr-4">{item.age}</td>
                    <td className="py-2 pr-4">{item.gender}</td>
                    <td className="py-2 pr-4">
                      <span
                        className={`px-2 py-0.5 rounded text-white text-xs font-bold ${
                          SEVERITY_STYLES[item.predicted_severity] || "bg-slate-500"
                        }`}
                      >
                        {item.predicted_severity}
                      </span>
                    </td>
                    <td className="py-2 pr-4 text-slate-500">
                      {item.high_risk_warning
                        ? "Referred to specialist"
                        : `${item.recommendations.length} therapy plan(s)`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
