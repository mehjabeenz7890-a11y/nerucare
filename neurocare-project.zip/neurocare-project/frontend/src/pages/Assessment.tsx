import { useState } from "react";
import AssessmentForm from "../components/AssessmentForm";
import Card from "../components/Card";
import AlertBox from "../components/AlertBox";
import RecommendationCard from "../components/RecommendationCard";
import ChatWindow from "../components/ChatWindow";
import { AssessmentPayload, AssessmentResponse, submitAssessment } from "../services/api";

const SEVERITY_STYLES: Record<string, string> = {
  Low: "bg-green-600",
  Moderate: "bg-orange-500",
  High: "bg-red-600",
};

export default function Assessment() {
  const [result, setResult] = useState<AssessmentResponse | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (payload: AssessmentPayload) => {
    setSubmitting(true);
    setError(null);
    try {
      const data = await submitAssessment(payload);
      setResult(data);
    } catch {
      setError("Assessment operational pipeline error. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <section className="lg:col-span-2 space-y-6">
        <Card title="Patient Clinical Ingestion Questionnaire">
          <AssessmentForm onSubmit={handleSubmit} submitting={submitting} />
        </Card>
        {error && <AlertBox variant="danger">{error}</AlertBox>}
      </section>

      <section className="space-y-6">
        <Card title="Analysis Summary" className="min-h-[250px]">
          {result ? (
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm uppercase font-bold text-slate-500">
                  Predicted Stage Severity:
                </span>
                <span
                  className={`px-3 py-1 rounded text-white font-bold text-sm ${
                    SEVERITY_STYLES[result.predicted_severity] || "bg-slate-500"
                  }`}
                >
                  {result.predicted_severity}
                </span>
              </div>

              {result.high_risk_warning ? (
                <AlertBox variant="danger" title={result.high_risk_warning}>
                  All standard functional recommendation protocols and automation
                  tracks have been locked down for patient safety.
                </AlertBox>
              ) : (
                <div className="space-y-4">
                  <h3 className="text-xs uppercase font-bold text-slate-400 tracking-wider">
                    Recommended Rehabilitation Therapy Plans
                  </h3>
                  {result.recommendations.length === 0 ? (
                    <p className="text-sm text-slate-500">
                      No specific therapy flags were triggered by the reported symptoms.
                    </p>
                  ) : (
                    result.recommendations.map((rec) => (
                      <RecommendationCard key={rec.therapy} rec={rec} />
                    ))
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="text-center text-slate-400 pt-12 text-sm">
              Submit a finalized patient assessment to generate rule summaries.
            </div>
          )}
        </Card>

        <ChatWindow severity={result?.predicted_severity || "Unknown"} />
      </section>
    </div>
  );
}
