import { Navigate, Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import Assessment from "./pages/Assessment";
import Assistant from "./pages/Assistant";
import Login from "./pages/Login";
import Register from "./pages/Register";
import { useAuth } from "./hooks/useAuth";

function ProtectedLayout({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return (
    <main className="flex-1 max-w-7xl w-full mx-auto p-4 flex gap-6">
      <Sidebar />
      <div className="flex-1">{children}</div>
    </main>
  );
}

export default function App() {
  const { isAuthenticated, token, logout } = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar isAuthenticated={isAuthenticated} onLogout={logout} />

      <div className="bg-amber-50 border-b border-amber-200 text-amber-900 p-3 text-xs text-center">
        <strong>Clinical Disclaimer:</strong> NeuroCare provides rehabilitation
        support recommendations for patients with an already confirmed
        neurological diagnosis. It does not diagnose disease, prescribe
        medication, or replace professional medical advice. All
        recommendations should be reviewed by a qualified neurologist or
        rehabilitation specialist.
      </div>

      <Routes>
        <Route
          path="/login"
          element={
            isAuthenticated ? (
              <Navigate to="/" replace />
            ) : (
              <Login onLoggedIn={() => window.location.reload()} />
            )
          }
        />
        <Route
          path="/register"
          element={isAuthenticated ? <Navigate to="/" replace /> : <Register />}
        />
        <Route
          path="/"
          element={
            <ProtectedLayout>
              <Dashboard />
            </ProtectedLayout>
          }
        />
        <Route
          path="/assessment"
          element={
            <ProtectedLayout>
              <Assessment />
            </ProtectedLayout>
          }
        />
        <Route
          path="/assistant"
          element={
            <ProtectedLayout>
              <Assistant />
            </ProtectedLayout>
          }
        />
        <Route path="*" element={<Navigate to={token ? "/" : "/login"} replace />} />
      </Routes>
    </div>
  );
}
