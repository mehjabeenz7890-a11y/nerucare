import { useCallback, useEffect, useState } from "react";
import { loginUser, registerUser } from "../services/api";

const TOKEN_KEY = "neurocare_token";

export function useAuth() {
  const [token, setToken] = useState<string | null>(
    () => localStorage.getItem(TOKEN_KEY)
  );

  useEffect(() => {
    if (token) {
      localStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  }, [token]);

  const login = useCallback(async (username: string, password: string) => {
    const data = await loginUser(username, password);
    setToken(data.access_token);
    return data;
  }, []);

  const register = useCallback(
    async (username: string, email: string, password: string, fullName?: string) => {
      return registerUser({ username, email, password, full_name: fullName });
    },
    []
  );

  const logout = useCallback(() => {
    setToken(null);
  }, []);

  return {
    token,
    isAuthenticated: Boolean(token),
    login,
    register,
    logout,
  };
}
