"""
Thin service layer around the ML predictor: builds the full raw feature map
expected by the trained model from an AssessmentInput payload.
"""
from typing import Dict

from app.schemas.assessment import AssessmentInput
from app.ml import predictor


def build_raw_features(data: AssessmentInput) -> Dict[str, object]:
    symptoms = data.symptoms
    return {
        "Age": data.age,
        "Gender": data.gender,
        "Disease": data.disease,
        "Sleep Quality": data.sleep_quality,
        "Physical Activity Level": data.physical_activity,
        "Fatigue": data.fatigue,
        "Falls in Last Month": data.falls_last_month,
        "Walking Difficulty": symptoms.get("Walking Difficulty", "None"),
        "Balance Problems": symptoms.get("Balance Problems", "None"),
        "Hand Tremor": symptoms.get("Hand Tremor", "None"),
        "Muscle Rigidity": symptoms.get("Muscle Rigidity", "None"),
        "Muscle Weakness": symptoms.get("Muscle Weakness", "None"),
        "Speech Difficulty": symptoms.get("Speech Difficulty", "None"),
        "Swallowing Difficulty": symptoms.get("Swallowing Difficulty", "None"),
        "Memory Problems": symptoms.get("Memory Problems", "None"),
        "Attention Difficulty": symptoms.get("Attention Difficulty", "None"),
        "Difficulty Performing Daily Activities": symptoms.get(
            "Difficulty Performing Daily Activities", "None"
        ),
    }


def predict_severity(data: AssessmentInput) -> str:
    raw_features = build_raw_features(data)
    return predictor.predict_severity(raw_features)
