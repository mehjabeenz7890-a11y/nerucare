"""
Orchestrates prediction + CDSS rule evaluation + persistence for a single
patient assessment submission.
"""
import json
from typing import List

from sqlalchemy.orm import Session

from app.database import models
from app.engine import cdss
from app.schemas.assessment import AssessmentInput, AssessmentResponse, TherapyRecommendation
from app.services import prediction_service


def run_assessment(
    db: Session, user: models.User, data: AssessmentInput
) -> AssessmentResponse:
    predicted_severity = prediction_service.predict_severity(data)

    high_risk = cdss.is_high_risk(predicted_severity, data.symptoms)

    if high_risk:
        predicted_severity = "High"
        recommendations: List[TherapyRecommendation] = []
        warning = cdss.HIGH_RISK_WARNING
    else:
        raw_recs = cdss.evaluate_rehabilitation_rules(data.symptoms, data.falls_last_month)
        recommendations = [TherapyRecommendation(**r) for r in raw_recs]
        warning = None

    record = models.Assessment(
        owner_id=user.id,
        disease=data.disease,
        age=data.age,
        gender=data.gender,
        sleep_quality=data.sleep_quality,
        physical_activity=data.physical_activity,
        fatigue=data.fatigue,
        falls_last_month=data.falls_last_month,
        symptoms_json=json.dumps(data.symptoms),
        predicted_severity=predicted_severity,
        recommendations_json=json.dumps([r.model_dump() for r in recommendations]),
        high_risk_warning=warning,
    )
    db.add(record)
    db.commit()
    db.refresh(record)

    return AssessmentResponse(
        id=record.id,
        predicted_severity=predicted_severity,
        recommendations=recommendations,
        high_risk_warning=warning,
        created_at=record.created_at,
    )


def get_history(db: Session, user: models.User) -> List[models.Assessment]:
    return (
        db.query(models.Assessment)
        .filter(models.Assessment.owner_id == user.id)
        .order_by(models.Assessment.created_at.desc())
        .all()
    )
