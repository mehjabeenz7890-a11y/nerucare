"""
Rule-based chat assistant responses, aware of the patient's latest predicted
severity so it can defer to a clinician for high-risk cases.
"""


def get_chat_response(message: str, severity: str) -> str:
    user_msg = message.lower()

    if severity == "High":
        return (
            "Your latest assessment suggests a higher level of impairment. "
            "NeuroCare cannot safely recommend rehabilitation exercises in this "
            "situation. Please consult your neurologist or rehabilitation "
            "specialist immediately."
        )

    if "exercise" in user_msg or "therapy" in user_msg:
        return (
            "Rehabilitation exercises should focus strictly on the specific "
            "symptoms flagged during assessment. For lower limb tracking, stick "
            "to standard dynamic balance training and target standard fine motor "
            "drills for dexterity constraints."
        )

    return (
        "I am the NeuroCare Assistant. I am configured to help provide disease "
        "education, guide you through your recommendation report, and offer "
        "exercise adherence motivation. Please remember that I cannot modify "
        "your physician's prescriptions."
    )
