"""Pydantic schemas for the clinical assessment endpoints."""
from datetime import datetime
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class AssessmentInput(BaseModel):
    disease: str
    symptoms: Dict[str, str] = Field(default_factory=dict)
    falls_last_month: int = 0
    age: int
    gender: str
    sleep_quality: str
    physical_activity: str
    fatigue: str


class TherapyRecommendation(BaseModel):
    therapy: str
    reason: str
    exercises: List[str]


class AssessmentResponse(BaseModel):
    id: Optional[int] = None
    predicted_severity: str
    recommendations: List[TherapyRecommendation]
    high_risk_warning: Optional[str] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class AssessmentHistoryItem(AssessmentResponse):
    disease: str
    age: int
    gender: str
