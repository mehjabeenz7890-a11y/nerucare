"""Pydantic schemas for the chat assistant endpoint."""
from typing import Optional

from pydantic import BaseModel


class ChatRequest(BaseModel):
    message: str
    severity: Optional[str] = "Unknown"


class ChatResponse(BaseModel):
    response: str
