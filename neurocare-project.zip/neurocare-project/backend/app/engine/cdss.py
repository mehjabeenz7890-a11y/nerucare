"""
Clinical Decision Support System — rehabilitation recommendation rule engine.

Deliberately kept free of any FastAPI / web-framework imports so it can be
unit-tested and reused in isolation (e.g. batch jobs, notebooks).
"""
from typing import Dict, List, TypedDict


class TherapyRecommendation(TypedDict):
    therapy: str
    reason: str
    exercises: List[str]


def evaluate_rehabilitation_rules(
    symptoms: Dict[str, str], falls: int
) -> List[TherapyRecommendation]:
    """Applies the clinical knowledge base rules to build evidence-based
    rehabilitation strategies for a non-high-risk patient."""
    recommendations: List[TherapyRecommendation] = []

    # Rule 1: Physiotherapy
    if (
        symptoms.get("Walking Difficulty") in ["Moderate", "Severe"]
        or symptoms.get("Balance Problems") in ["Moderate", "Severe"]
        or falls >= 2
    ):
        recommendations.append(
            {
                "therapy": "Physiotherapy",
                "reason": (
                    "Detected significant locomotive risks (Walking: "
                    f"{symptoms.get('Walking Difficulty', 'None')}, "
                    f"Balance: {symptoms.get('Balance Problems', 'None')}, Falls: {falls})."
                ),
                "exercises": [
                    "Static & Dynamic Balance Training",
                    "Assisted Gait Track Drills",
                    "Lower Limb Progressive Strengthening",
                ],
            }
        )

    # Rule 2: Occupational Therapy
    if (
        symptoms.get("Difficulty Performing Daily Activities") in ["Moderate", "Severe"]
        or symptoms.get("Hand Tremor") in ["Moderate", "Severe"]
        or symptoms.get("Muscle Rigidity") in ["Moderate", "Severe"]
    ):
        recommendations.append(
            {
                "therapy": "Occupational Therapy",
                "reason": (
                    "Patient exhibits fine-motor impairment or performance blockages "
                    "during regular baseline activities of daily living (ADLs)."
                ),
                "exercises": [
                    "Fine Motor Coordination Tasks",
                    "Adaptive Dressing & Utensil Practice",
                    "Upper Extremity Energy Conservation Layouts",
                ],
            }
        )

    # Rule 3: Speech & Language Therapy
    if symptoms.get("Speech Difficulty") in ["Moderate", "Severe"] or symptoms.get(
        "Swallowing Difficulty"
    ) in ["Mild", "Moderate", "Severe"]:
        recommendations.append(
            {
                "therapy": "Speech & Language Therapy",
                "reason": (
                    "Bulbar signs identified. Presenting issues with communication "
                    "tracking or high-risk execution transitions."
                ),
                "exercises": [
                    "Lee Silverman Voice Technique (LSVT) Vocal Loudness Drills",
                    "Pharyngeal Swallowing Reflex Reinforcement Exercises",
                    "Controlled Breath-Speech Pacing Exercises",
                ],
            }
        )

    # Rule 4: Cognitive Rehabilitation
    if symptoms.get("Memory Problems") in ["Moderate", "Severe"] or symptoms.get(
        "Attention Difficulty"
    ) in ["Moderate", "Severe"]:
        recommendations.append(
            {
                "therapy": "Cognitive Rehabilitation",
                "reason": (
                    "Deficits mapped across objective working memory capacities or "
                    "structural internal filtering tracks."
                ),
                "exercises": [
                    "Spatiotemporal Orientation Journals",
                    "Structured Working Memory Sequence Tasks",
                    "Environmental Association Methods",
                ],
            }
        )

    return recommendations


def is_high_risk(predicted_severity: str, symptoms: Dict[str, str]) -> bool:
    """Safety guardrail: escalate to high-risk if the model predicts High severity
    OR swallowing difficulty is Severe, regardless of model output."""
    return predicted_severity == "High" or symptoms.get("Swallowing Difficulty") == "Severe"


HIGH_RISK_WARNING = (
    "\u26a0 High Risk Detected. Based on your assessment, your condition appears to "
    "require evaluation by a neurologist or rehabilitation specialist. NeuroCare "
    "cannot safely recommend rehabilitation therapy or home exercises for high-risk "
    "patients."
)
