"""Chat assistant routes."""
from fastapi import APIRouter, Depends

from app.core.security import get_current_user
from app.database import models
from app.schemas.chat import ChatRequest, ChatResponse
from app.services import chat_service

router = APIRouter(prefix="/chat", tags=["Chat Assistant"])


@router.post("", response_model=ChatResponse)
def chat(
    payload: ChatRequest,
    current_user: models.User = Depends(get_current_user),
):
    response_text = chat_service.get_chat_response(payload.message, payload.severity or "Unknown")
    return ChatResponse(response=response_text)
