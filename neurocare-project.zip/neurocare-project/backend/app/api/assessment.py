"""Assessment routes: submit a new assessment, view history."""
from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.security import get_current_user
from app.database import models
from app.database.session import get_db
from app.schemas.assessment import AssessmentHistoryItem, AssessmentInput, AssessmentResponse
from app.services import assessment_service

router = APIRouter(prefix="/assessment", tags=["Assessment"])


@router.post("", response_model=AssessmentResponse)
def submit_assessment(
    payload: AssessmentInput,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    return assessment_service.run_assessment(db, current_user, payload)


@router.get("/history", response_model=List[AssessmentHistoryItem])
def assessment_history(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    records = assessment_service.get_history(db, current_user)
    import json

    return [
        AssessmentHistoryItem(
            id=r.id,
            disease=r.disease,
            age=r.age,
            gender=r.gender,
            predicted_severity=r.predicted_severity,
            recommendations=json.loads(r.recommendations_json or "[]"),
            high_risk_warning=r.high_risk_warning,
            created_at=r.created_at,
        )
        for r in records
    ]
