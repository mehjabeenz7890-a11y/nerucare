"""
NeuroCare CDSS Platform — FastAPI application entrypoint.
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import assessment, auth, chat
from app.core.config import settings
from app.database.session import init_db
from app.ml import predictor
from app.utils.logger import get_logger

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting NeuroCare backend...")
    init_db()
    predictor.load_artifacts()  # loads (or trains once) then caches the RF model
    logger.info("Startup complete. NeuroCare API is ready.")
    yield
    logger.info("Shutting down NeuroCare backend.")


app = FastAPI(
    title=settings.PROJECT_NAME,
    description=(
        "Evidence-based rehabilitation therapy recommendation platform for "
        "patients with an already confirmed neurological diagnosis. Does not "
        "diagnose disease, prescribe medication, or replace professional "
        "medical advice."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix=settings.API_V1_PREFIX)
app.include_router(assessment.router, prefix=settings.API_V1_PREFIX)
app.include_router(chat.router, prefix=settings.API_V1_PREFIX)


@app.get("/health", tags=["Health"])
async def health_check():
    return {"status": "ok", "service": settings.PROJECT_NAME}
