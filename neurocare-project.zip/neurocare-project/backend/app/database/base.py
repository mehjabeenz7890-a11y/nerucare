"""
SQLAlchemy declarative base. Import all models here so Alembic / create_all
can discover them via Base.metadata.
"""
from sqlalchemy.orm import declarative_base

Base = declarative_base()
