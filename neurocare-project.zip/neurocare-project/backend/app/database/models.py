"""
ORM models: User accounts and stored patient Assessments.
"""
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.database.base import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, index=True, nullable=False)
    email = Column(String(128), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(128), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    assessments = relationship(
        "Assessment", back_populates="owner", cascade="all, delete-orphan"
    )


class Assessment(Base):
    __tablename__ = "assessments"

    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    disease = Column(String(64), nullable=False)
    age = Column(Integer, nullable=False)
    gender = Column(String(16), nullable=False)
    sleep_quality = Column(String(16), nullable=False)
    physical_activity = Column(String(16), nullable=False)
    fatigue = Column(String(16), nullable=False)
    falls_last_month = Column(Integer, default=0)

    symptoms_json = Column(Text, nullable=False)  # serialized dict of symptom -> level
    predicted_severity = Column(String(16), nullable=False)
    recommendations_json = Column(Text, nullable=True)  # serialized recommendation list
    high_risk_warning = Column(Text, nullable=True)

    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    owner = relationship("User", back_populates="assessments")
