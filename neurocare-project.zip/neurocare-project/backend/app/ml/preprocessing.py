"""
Synthetic clinical dataset generation and preprocessing helpers.

This mirrors the original clinically-guided data generation used to bootstrap
the severity classifier, extracted verbatim in behaviour from the legacy
monolithic implementation.
"""
import os
import random
from typing import Tuple

import pandas as pd
from sklearn.preprocessing import LabelEncoder

DISEASES = [
    "Parkinson's Disease",
    "Alzheimer's Disease",
    "Multiple Sclerosis",
    "Huntington's Disease",
]
SYMPTOM_LEVELS = ["None", "Mild", "Moderate", "Severe"]
ACTIVITY_LEVELS = ["None", "Light", "Moderate", "Regular"]
SLEEP_LEVELS = ["Excellent", "Good", "Fair", "Poor"]

ALL_SYMPTOMS = [
    "Walking Difficulty",
    "Balance Problems",
    "Hand Tremor",
    "Muscle Rigidity",
    "Muscle Weakness",
    "Speech Difficulty",
    "Swallowing Difficulty",
    "Memory Problems",
    "Attention Difficulty",
    "Difficulty Performing Daily Activities",
]

LABEL_COLUMN = "Disease Severity"


def _build_record() -> dict:
    disease = random.choice(DISEASES)
    record = {
        "Age": random.randint(30, 85) if disease != "Multiple Sclerosis" else random.randint(20, 55),
        "Gender": random.choice(["Male", "Female"]),
        "Disease": disease,
        "Sleep Quality": random.choice(SLEEP_LEVELS),
        "Physical Activity Level": random.choice(ACTIVITY_LEVELS),
        "Fatigue": random.choice(SYMPTOM_LEVELS),
        "Falls in Last Month": random.randint(0, 4)
        if disease in ["Parkinson's Disease", "Multiple Sclerosis", "Huntington's Disease"]
        else 0,
    }

    if disease == "Parkinson's Disease":
        record["Hand Tremor"] = random.choice(["Moderate", "Severe", "Mild"])
        record["Muscle Rigidity"] = random.choice(["Moderate", "Severe", "Mild"])
        record["Walking Difficulty"] = random.choice(SYMPTOM_LEVELS)
        record["Memory Problems"] = random.choice(["None", "Mild"])
    elif disease == "Alzheimer's Disease":
        record["Memory Problems"] = random.choice(["Moderate", "Severe"])
        record["Difficulty Performing Daily Activities"] = random.choice(["Moderate", "Severe"])
        record["Hand Tremor"] = "None"
        record["Muscle Rigidity"] = "None"
    elif disease == "Multiple Sclerosis":
        record["Muscle Weakness"] = random.choice(["Moderate", "Severe", "Mild"])
        record["Balance Problems"] = random.choice(["Moderate", "Severe", "Mild"])
        record["Hand Tremor"] = "None"
    elif disease == "Huntington's Disease":
        record["Speech Difficulty"] = random.choice(["Mild", "Moderate", "Severe"])
        record["Swallowing Difficulty"] = random.choice(SYMPTOM_LEVELS)
        record["Balance Problems"] = random.choice(["Moderate", "Severe"])
        record["Hand Tremor"] = "None"

    for s in ALL_SYMPTOMS:
        if s not in record:
            record[s] = random.choice(["None", "Mild", "Moderate"])

    severe_indicators = sum(1 for v in record.values() if v == "Severe")
    moderate_indicators = sum(1 for v in record.values() if v == "Moderate")

    if (
        severe_indicators >= 2
        or record.get("Swallowing Difficulty") == "Severe"
        or record["Falls in Last Month"] >= 3
    ):
        record[LABEL_COLUMN] = "High"
    elif moderate_indicators >= 3 or severe_indicators == 1:
        record[LABEL_COLUMN] = "Moderate"
    else:
        record[LABEL_COLUMN] = "Low"

    return record


def generate_clinical_dataset(dataset_path: str, n_records: int = 15000) -> pd.DataFrame:
    """Generates a clinically-guided synthetic dataset and persists it to CSV."""
    records = [_build_record() for _ in range(n_records)]
    df = pd.DataFrame(records)
    os.makedirs(os.path.dirname(dataset_path), exist_ok=True)
    df.to_csv(dataset_path, index=False)
    return df


def load_or_generate_dataset(dataset_path: str, n_records: int = 15000) -> pd.DataFrame:
    if os.path.exists(dataset_path):
        return pd.read_csv(dataset_path)
    return generate_clinical_dataset(dataset_path, n_records)


def encode_features(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series, dict]:
    """Splits features/label and label-encodes categorical columns.

    Returns the encoded feature frame, label series, and a dict of fitted
    LabelEncoders keyed by column name (used again at inference time).
    """
    X = df.drop(columns=[LABEL_COLUMN])
    y = df[LABEL_COLUMN]

    encoders: dict = {}
    for col in X.select_dtypes(include=["object"]).columns:
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col].astype(str))
        encoders[col] = le

    return X, y, encoders
