"""
Offline training script for the Disease Severity RandomForest classifier.

Run explicitly to (re)train and persist model artifacts:

    python -m app.ml.train

The FastAPI application never trains at import/startup time — it only loads
the artifacts produced here. This keeps server boot fast and deterministic.
"""
import os

import joblib
from sklearn.ensemble import RandomForestClassifier

from app.core.config import settings
from app.ml.preprocessing import encode_features, load_or_generate_dataset


def train_and_save_model() -> None:
    os.makedirs(settings.ML_ARTIFACTS_DIR, exist_ok=True)

    df = load_or_generate_dataset(settings.DATASET_FILE, settings.DATASET_SIZE)
    X, y, encoders = encode_features(df)
    feature_names = list(X.columns)

    print(f"Training RandomForestClassifier on {len(df)} records...")
    model = RandomForestClassifier(n_estimators=50, max_depth=8, random_state=42)
    model.fit(X, y)

    joblib.dump(model, os.path.join(settings.ML_ARTIFACTS_DIR, "model.pkl"))
    joblib.dump(encoders, os.path.join(settings.ML_ARTIFACTS_DIR, "encoders.pkl"))
    joblib.dump(feature_names, os.path.join(settings.ML_ARTIFACTS_DIR, "feature_columns.pkl"))

    print("Model, encoders, and feature columns saved to:", settings.ML_ARTIFACTS_DIR)


if __name__ == "__main__":
    train_and_save_model()
