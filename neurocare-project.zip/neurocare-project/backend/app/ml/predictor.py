"""
Loads trained ML artifacts exactly once (module-level singleton) and exposes
a simple predict() function used by the prediction service.

If artifacts are missing (e.g. first-ever run), training is triggered once
and the resulting artifacts are cached to disk so subsequent server starts
load instantly instead of retraining.
"""
import os
import threading
from typing import Dict, List

import joblib

from app.core.config import settings
from app.utils.logger import get_logger

logger = get_logger(__name__)

_lock = threading.Lock()
_model = None
_encoders: Dict = {}
_feature_names: List[str] = []


def _artifact_path(name: str) -> str:
    return os.path.join(settings.ML_ARTIFACTS_DIR, name)


def _artifacts_exist() -> bool:
    return all(
        os.path.exists(_artifact_path(f))
        for f in ("model.pkl", "encoders.pkl", "feature_columns.pkl")
    )


def load_artifacts() -> None:
    """Loads model/encoders/feature list into memory once. Thread-safe."""
    global _model, _encoders, _feature_names

    with _lock:
        if _model is not None:
            return  # already loaded

        if not _artifacts_exist():
            logger.info("ML artifacts not found. Training model for the first time...")
            from app.ml.train import train_and_save_model

            train_and_save_model()

        logger.info("Loading ML artifacts from %s", settings.ML_ARTIFACTS_DIR)
        _model = joblib.load(_artifact_path("model.pkl"))
        _encoders = joblib.load(_artifact_path("encoders.pkl"))
        _feature_names = joblib.load(_artifact_path("feature_columns.pkl"))
        logger.info("ML artifacts loaded. Model ready for inference.")


def get_feature_names() -> List[str]:
    if not _feature_names:
        load_artifacts()
    return _feature_names


def predict_severity(raw_features: Dict[str, object]) -> str:
    """Encodes a raw feature dict (matching training schema) and predicts severity."""
    if _model is None:
        load_artifacts()

    row = []
    for feat in _feature_names:
        val = raw_features.get(feat, "None")
        if feat in _encoders:
            try:
                val = _encoders[feat].transform([str(val)])[0]
            except ValueError:
                val = 0  # unseen category fallback
        row.append(val)

    prediction = _model.predict([row])
    return str(prediction[0])
