# NeuroCare Backend

FastAPI backend for the NeuroCare Clinical Decision Support System (CDSS) — a
rehabilitation therapy recommendation platform for patients with an already
confirmed neurological diagnosis (Parkinson's, Alzheimer's, Multiple
Sclerosis, Huntington's Disease).

> **Clinical disclaimer:** NeuroCare does not diagnose disease, prescribe
> medication, or replace professional medical advice. All output is a
> recommendation support tool intended for review by a qualified neurologist
> or rehabilitation specialist.

## Architecture

```
app/
├── main.py            FastAPI app, CORS, startup lifecycle
├── api/                HTTP routers (auth, assessment, chat)
├── core/                config.py (env settings), security.py (JWT/bcrypt)
├── database/            SQLAlchemy Base, session, ORM models
├── ml/                   preprocessing, train, predictor (RandomForest)
│   └── artifacts/        persisted model.pkl / encoders.pkl / feature_columns.pkl
├── engine/cdss.py        pure rule-based rehabilitation recommendation engine
├── schemas/              Pydantic request/response models
├── services/              orchestration layer between API and ML/CDSS/DB
└── utils/logger.py
```

## Setup

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # edit SECRET_KEY etc. for production
```

## Train the ML model (first run only)

The model is **not** retrained on every server start. Train once explicitly:

```bash
python -m app.ml.train
```

This generates the synthetic clinical dataset (if absent) and writes
`model.pkl`, `encoders.pkl`, `feature_columns.pkl` into `app/ml/artifacts/`.

If you skip this step, the API will auto-train on first startup and cache the
result — subsequent restarts load instantly from the saved artifacts.

## Run the server

```bash
uvicorn app.main:app --reload --port 8000
```

API docs: http://localhost:8000/docs

## API Endpoints

| Method | Path                    | Auth | Description                          |
|--------|-------------------------|------|--------------------------------------|
| POST   | /api/auth/register      | No   | Create a new user account            |
| POST   | /api/auth/login         | No   | OAuth2 password login, returns JWT   |
| POST   | /api/assessment         | Yes  | Submit assessment, get severity + recommendations |
| GET    | /api/assessment/history | Yes  | List the current user's past assessments |
| POST   | /api/chat               | Yes  | Chat with the rule-based assistant   |
| GET    | /health                 | No   | Liveness check                       |

Authenticated routes expect `Authorization: Bearer <token>`.

## Database

Defaults to local SQLite (`neurocare.db`). To use PostgreSQL, set
`DATABASE_URL=postgresql+psycopg2://user:password@host:5432/neurocare` in
`.env` and add `psycopg2-binary` to `requirements.txt`. The project is
structured to plug in Alembic migrations against `app/database/base.py`'s
`Base.metadata`.

## Docker

```bash
docker build -t neurocare-backend .
docker run -p 8000:8000 --env-file .env neurocare-backend
```
