# NeuroCare CDSS Platform

Evidence-based rehabilitation therapy recommendation platform for patients
with an already confirmed neurological diagnosis (Parkinson's Disease,
Alzheimer's Disease, Multiple Sclerosis, Huntington's Disease).

> **Clinical disclaimer:** NeuroCare does not diagnose disease, prescribe
> medication, or replace professional medical advice. All recommendations
> should be reviewed by a qualified neurologist or rehabilitation specialist.

This repository contains the production-ready, modular rewrite of the
original single-file prototype. All ML logic, CDSS rules, prediction
workflow, API behavior, and chatbot behavior have been preserved and moved
into a clean, layered architecture.

```
neurocare-project/
├── backend/     FastAPI + SQLAlchemy + JWT auth + RandomForest ML + CDSS engine
└── frontend/    React + TypeScript + Vite + Tailwind CSS
```

## Quick Start

### 1. Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m app.ml.train        # trains and saves the severity classifier once
uvicorn app.main:app --reload --port 8000
```

API docs: http://localhost:8000/docs

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

App: http://localhost:5173

## What changed vs. the original prototype

| Original (single file)              | Refactored                                             |
|--------------------------------------|---------------------------------------------------------|
| Dataset generated + model trained on every server boot | Trained once via `app/ml/train.py`, artifacts loaded from disk on startup |
| No persistence — results only in memory | SQLite/PostgreSQL via SQLAlchemy; assessment history per user |
| No authentication                    | JWT auth (register/login), protected routes             |
| CDSS rules inline in the API handler | Extracted into a pure, framework-independent `engine/cdss.py` |
| Embedded Vue/CDN HTML string in FastAPI | Standalone React + TypeScript + Vite + Tailwind app     |
| One monolithic `main.py`             | Layered `api/ → services/ → ml/ / engine/ / database/`  |

See `backend/README.md` and `frontend/README.md` for details on each half of
the stack, including full API reference and Docker instructions.

## License

Internal clinical decision-support tooling — not licensed for public
redistribution.
